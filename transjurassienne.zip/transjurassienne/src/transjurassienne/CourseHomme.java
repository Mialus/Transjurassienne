package transjurassienne;

public class CourseHomme extends Course {

    public CourseHomme(float km, String nom){
        super(km,nom);
    }
}
