package transjurassienne;

public class CourseFemme extends Course {
    
    public CourseFemme(float km, String nom){
        super(km,nom);
    }
    
}
